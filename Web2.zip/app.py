from flask import Flask, render_template, request
import re
from bot import *
from urllib.parse import urlparse

app = Flask(__name__)

BLACKLIST_TAGS = {
    'script', 'iframe', 'object', 'embed', 'link', 'style',
    'img', 'image', 'base', 'svg', 'math', 'form', 'input', 'textarea',
    'select', 'option', 'button', 'datalist', 'keygen', 'output',
    'meta', 'basefont', 'bgsound', 'frame', 'frameset', 'noframes',
    'applet', 'param', 'source', 'track', 'video', 'audio', 'canvas',
    'template', 'noscript', 'plaintext', 'xss', 'xml', 'marquee',
    'blink', 'layer', 'ilayer', 'title', 'style', 'details', 'dialog',
    'menu', 'menuitem', 'summary', 'picture', 'figure', 'figcaption',
    'code', 'slot', 'aside', 'footer', 'header', 'nav', 'section',
    'article', 'address', 'main', 'div', 'span', 'p', 'a', 'ul', 'ol',
    'li', 'dl', 'dt', 'dd', 'table', 'caption', 'col', 'colgroup',
    'tbody', 'thead', 'tfoot', 'tr', 'th', 'td', 'ruby', 'rt', 'rp',
    'rtc', 'b', 'i', 'u', 'em', 'strong', 'small', 'big', 'abbr',
    'acronym', 'cite', 'code', 'dfn', 'kbd', 'samp', 'var', 'time',
    'mark', 'q', 'blockquote', 'ins', 'del', 'pre', 'hr', 'br', 'wbr',
    'sub', 'sup', 'progress', 'meter', 'fieldset', 'legend', 'label',
    'output', 'area', 'map',
}


tag_regex = re.compile(r'<(/?[A-Za-z]+)([^>]*?)(/?)>', re.IGNORECASE)

class Parse:
    def __init__(self):
        self.index = 0
        self.html = ""
        self.result = []  
        self.in_p_tag = False  

    def parse(self, html):
        self.html = html
        self.index = 0
        self.result = []

        while self.index < len(self.html):
            if self.html[self.index] == '<':  
                tag = self.get_next_tag()
                if not tag:
                    self.index += 1
                    continue

                tag_name_match = re.match(r'</?([A-Za-z]+)', tag, re.IGNORECASE)
                if not tag_name_match:
                    self.index += 1
                    continue

                tag_name = tag_name_match.group(1).lower()
                if tag_name in BLACKLIST_TAGS:
                    continue 

                mutated_tag = self.mutate_tag(tag)

                if tag_name == 'p':
                    if '</p>' in mutated_tag.lower():  
                        if self.in_p_tag:
                            self.result.append('</p>')  
                            self.in_p_tag = False
                    else:
                        if not self.in_p_tag:  
                            self.result.append('<p>')
                            self.in_p_tag = True
                else:
                    self.result.append(mutated_tag)
            else:
                content = self.get_text_until_tag()
                self.result.append(content)

        if self.in_p_tag:
            self.result.append('</p>')

        return ''.join(self.result)

    def get_next_tag(self):
        match = tag_regex.search(self.html, self.index)
        if match:
            tag = match.group(0)
            if '>' not in tag:
                return None
            self.index = match.end()
            return tag
        return None

    def get_text_until_tag(self):
        next_tag_pos = self.html.find('<', self.index)
        if next_tag_pos == -1:  
            text = self.html[self.index:]
            self.index = len(self.html)
            return text
        text = self.html[self.index:next_tag_pos]
        self.index = next_tag_pos
        return text

    def mutate_tag(self, tag):
        tag_lower = tag.lower()
        if tag_lower.startswith('<div'):
            tag = re.sub(r'<div', '<section', tag, flags=re.IGNORECASE)
        elif tag_lower.startswith('</div'):
            tag = re.sub(r'</div', '</section', tag, flags=re.IGNORECASE)
        
        if tag_lower.startswith('<span'):
            tag = re.sub(r'<span', '<strong', tag, flags=re.IGNORECASE)
        elif tag_lower.startswith('</span'):
            tag = re.sub(r'</span', '</strong', tag, flags=re.IGNORECASE)
        
        if tag_lower.startswith('<b'):
            tag = re.sub(r'<b', '<i', tag, flags=re.IGNORECASE)
        elif tag_lower.startswith('</b'):
            tag = re.sub(r'</b', '</i', tag, flags=re.IGNORECASE)
        
        return tag

@app.route('/', methods=['GET', 'POST'])
def index():
    parsed_output = ""
    html_input = ""
    if request.method == 'POST':
        html_input = request.form.get('html_input', '')
    elif request.method == 'GET':
        html_input = request.args.get('html_input', '')

    if html_input:
        parser = Parse()
        parsed_output = parser.parse(html_input)
    return render_template('index.html', parsed_output=parsed_output)

@app.route("/report", methods=["POST"])
def report():
    bot = Bot()
    url = request.form.get('url')
    if url:
        try:
            parsed_url = urlparse(url)
        except Exception:
            return {"error": "Invalid URL."}, 400
        if parsed_url.scheme not in ["http", "https"]:
            return {"error": "Invalid scheme."}, 400
        if parsed_url.hostname not in ["127.0.0.1", "localhost"]:
            return {"error": "Invalid host."}, 401
        
        bot.visit(url)
        bot.close()
        return {"visited":url}, 200
    else:
        return {"error":"URL parameter is missing!"}, 400

if __name__ == '__main__':
    app.run(debug=True, port=8000,host="0.0.0.0")
